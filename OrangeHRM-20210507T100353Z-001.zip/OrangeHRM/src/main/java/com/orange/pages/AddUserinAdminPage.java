package com.orange.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.orange.base.Base;

public class AddUserinAdminPage extends Base{

	//xpath declaration for headers 
	
	@FindBy(xpath="//*[@id='menu_admin_viewAdminModule']/b") 
	WebElement adminLable;
	
	@FindBy(xpath="//*[@id='menu_admin_UserManagement']")
	WebElement userManagmentLable;

	@FindBy(xpath="//*[@id='menu_admin_viewSystemUsers']")
	WebElement userLable;
	
	@FindBy(xpath="//*[@id='btnAdd']")   ////*[@id="btnAdd"]
	WebElement addButton;
	

	//xpath declaration of Add user Form
	
	@FindBy(xpath="//*[@id='systemUser_employeeName_empName']")
	WebElement employeeNameTextbox; 

	
	@FindBy(xpath="//*[@id='systemUser_userName']")
	WebElement userNameTextbox;
	
	@FindBy(xpath="//*[@id='systemUser_password']")
	WebElement passwordTextbox;
	
	@FindBy(xpath="//*[@id='systemUser_confirmPassword']")
	WebElement confirmPasswordTextbox;
	
	@FindBy(xpath="//*[@id='btnSave']")
	WebElement saveButton;
	
	
	
	
	public AddUserinAdminPage() {
		PageFactory.initElements(driver, this);
	}
	
	
	//method declaration
	
	public boolean adminLablePresence() {
		return adminLable.isDisplayed();
		
	}
	
	public boolean userManagmentLablePresence() {
		adminLable.click();
		userManagmentLable.click();
		return userManagmentLable.isDisplayed();
		
	}
	
	public void userLablePresence() {
		userManagmentLable.click();
		userLable.isDisplayed();
		userLable.click();
	}
	
	public void addButton() {
		addButton.isDisplayed();
		addButton.click();
		
	}
	
	
	public boolean employeeNameTextboxPresence() {
		return employeeNameTextbox.isDisplayed();
		
	}
	
	public boolean userNameTextboxPresence() {
		return userNameTextbox.isDisplayed();
	}
	
	public boolean passwordTextboxPresence() {
		return passwordTextbox.isDisplayed();
	}
	
	
	public boolean confirmPasswordTextboxPresence() {
		return confirmPasswordTextbox.isDisplayed();
	}
	public void saveButton() {
		saveButton.click();
	}
	
	
	
}




